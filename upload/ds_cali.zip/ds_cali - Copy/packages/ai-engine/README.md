# AI Engine

Shared package for AI vision analysis.

## Modules

- `prompt.ts`: prompt templates for OpenAI/Gemini.
- `schema.ts`: Zod schema for meal analysis output.
- `parse.ts`: parse and validate AI response.
- `volume.ts`: volume correction using depth map.
- `fallback.ts`: model fallback logic.

## Usage (Backend)

```typescript
import { analyzeMealImage } from '@cal-ai/ai-engine';

const result = await analyzeMealImage({
  imageUrl,
  depthMapUrl,
  referenceObject: 'plate',
});