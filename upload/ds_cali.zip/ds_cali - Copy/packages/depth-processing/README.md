# Depth Processing

Utilities for depth map handling.

## Functions

- `normalizeDepthMap(buffer: ArrayBuffer, width: number, height: number): Float32Array`
- `estimateVolume(segmentationMask, depthMap, cameraIntrinsics): number`
- `compressDepthMap(float32Array: Float32Array): Uint8Array`
- `decompressDepthMap(compressed: Uint8Array): Float32Array`