# Shared Contracts

Central place for TypeScript types and Zod schemas.

## Files

- `user.ts`
- `food.ts`
- `meal.ts`
- `log.ts`
- `health.ts`
- `api.ts` (request/response schemas)

All types are exported from index.