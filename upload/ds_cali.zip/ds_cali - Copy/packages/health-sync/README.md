# Health Sync Package

Native module interfaces for HealthKit and Google Fit.

## Exports

- `getDailyMetrics(date: Date): Promise<HealthMetrics>`
- `getWorkouts(date: Date): Promise<WorkoutSummary[]>`
- `requestPermissions(): Promise<void>`
- `disconnect(): Promise<void>`

## Platform Implementations

- iOS: `ios/HealthSync.swift`
- Android: `android/HealthSync.kt`