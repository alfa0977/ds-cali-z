# Project Breakdown

This document breaks the project into tasks and sub-tasks with dependencies and estimated complexity. It is designed for a code agent to follow sequentially.

## Phase 0 – Foundation

### T0.1 Monorepo Setup
- Initialize pnpm workspace, Turborepo
- Create folder structure for `apps`, `packages`
- Configure TypeScript, ESLint, Prettier shared configs
- Add CI workflow (`.github/workflows`)

### T0.2 Mobile App Scaffold
- Create Expo app with TypeScript template
- Install and configure React Navigation
- Set up Zustand store and React Query
- Set up theme provider from `packages/ui`

### T0.3 Firebase Setup
- Create Firebase project, enable Auth, Firestore, Storage, Functions
- Configure Firebase SDK in mobile app
- Initialize Firebase Functions project (v2)
- Set up local emulator

### T0.4 Shared Contracts Package
- Define core types: `User`, `Food`, `Log`, `Meal`, `HealthDaily`
- Create Zod schemas for API request/response validation

---

## Phase 1 – User Profile & Onboarding

### T1.1 Authentication
- Implement Apple Sign-In using `@invertase/react-native-apple-authentication`
- Implement Google Sign-In using `@react-native-google-signin/google-signin`
- Integrate with Firebase Auth
- Handle token refresh, logout

### T1.2 User Profile
- Screen to enter goals (calories, macros), weight, height
- Save to Firestore under `users/{userId}`
- Profile picture upload (optional)

### T1.3 Health Permissions
- Create native module `HealthSync`
- Request HealthKit read permissions (steps, active energy, weight, workouts)
- Request Google Fit OAuth scopes
- Store permission status

### T1.4 Settings
- Settings screen with profile edit, notification preferences, data deletion
- Logout button

### T1.5 Paywall Skeleton
- Integrate RevenueCat SDK
- Create basic paywall UI (non-functional)
- Add "Restore Purchases" button placeholder

---

## Phase 2 – Manual & Barcode Logging

### T2.1 Food Database
- Seed Firestore with a starter food database (CSV import)
- API endpoint `/searchFoods` with text search
- Food detail retrieval

### T2.2 Barcode Scanner
- Use `expo-barcode-scanner` (or `expo-camera` barcode scanning)
- Lookup barcode via external API (e.g., Open Food Facts) or local DB
- If not found, allow manual entry

### T2.3 Manual Food Entry
- UI with description field, serving size, macro fields
- Call `/logFood` to save

### T2.4 Log Meal
- API `/logMeal` to save a log with one or more foods
- Recent feed query on Home dashboard

---

## Phase 3 – AI Visual Logger

### T3.1 Camera Scanner UI
- Camera screen with overlay grid
- Lighting detection using expo-camera's exposure
- "Capture" button

### T3.2 Depth Capture Native Module
- Implement ARKit/ARCore session using `react-native-arkit` / `react-native-arcore` (or custom native)
- Capture RGB image + depth map (if available)
- Expose method `captureWithDepth()`

### T3.3 Upload Service
- Function to upload image to Firebase Storage (compress first)
- Function to upload depth map (binary)

### T3.4 AI Engine Package
- Prompt templates for GPT-4o/Gemini
- JSON schema for meal analysis output
- Response parsing and Zod validation
- Fallback logic (if OpenAI fails, use Gemini)

### T3.5 Backend Endpoint `/analyzeMeal`
- Accept image URL, depth map URL, reference object
- Call AI service
- Enrich with food density database for weight correction
- Store raw and corrected analysis in Firestore
- Return result

### T3.6 Result Card UI
- Display macros (calories, protein, carbs, fat)
- Health score with icon
- Ingredient list with estimated weights
- "Fix Results" button opening edit modal

### T3.7 Fix Results Flow
- Allow user to add/remove ingredients, adjust portions
- Recalculate macros locally
- Save corrected meal to Firestore

---

## Phase 4 – Dashboards

### T4.1 Weekly Habit Tracker
- Circular rings for each day (S,M,T,W,T,F,S)
- Fetch days logged from Firestore for current week
- Animate rings

### T4.2 Steps Card
- Read steps from HealthKit/Google Fit via native module
- Display in circular progress with goal 10,000
- Sync daily steps to Firestore (aggregate)

### T4.3 Calories Burned Card
- Combine steps (converted to calories) and workouts (active energy) from health sync
- Display with flame icon

### T4.4 Water Logging Card
- +/- buttons to adjust water intake
- Save water log to Firestore
- Optionally write to HealthKit

### T4.5 Recent Feed
- Query logs for today (or selected date)
- Display thumbnail, title, time, total calories, macro breakdown

### T4.6 Progress Dashboard
- Weight graph using `react-native-svg` or `victory-native`
- Last weight widget (circular)
- Days logged widget
- Time filter buttons
- Motivation banner

---

## Phase 5 – Monetization, Sync, Polish

### T5.1 RevenueCat Integration
- Configure subscription products (monthly, yearly)
- Paywall UI with purchase actions
- Restore purchases
- Webhook to update Firestore subscription status

### T5.2 Health Sync Background
- Use native background fetch or scheduled task to pull health data
- Aggregate daily metrics and send to `/syncHealth`
- Handle token refresh for Google Fit

### T5.3 Analytics & Crash Reporting
- Firebase Analytics events (meal_logged, scan_completed, subscription)
- Crashlytics setup

### T5.4 Performance & Security
- Image compression before upload
- Firestore security rules review
- Storage rules
- API rate limiting

### T5.5 Beta Release
- App store connect / Play console setup
- TestFlight / internal testing
- Fix critical bugs