# Payments & Monetization

## RevenueCat Integration

- RevenueCat handles Apple App Store and Google Play subscriptions.
- App uses RevenueCat SDK to manage purchases and check entitlement.

## Products

- `calai_monthly`: Monthly subscription (e.g., $9.99/mo)
- `calai_yearly`: Yearly subscription (e.g., $59.99/yr, with free trial)

## Entitlements

- `premium`: unlocks unlimited AI scans, advanced analytics, ad-free.

## Mobile Implementation

- Configure RevenueCat with API keys (in `.env`).
- On app launch, initialize RevenueCat and fetch offerings.
- When user attempts premium feature, check `hasEntitlement('premium')`.
- If not, show paywall.

## Paywall UI

- Show features list, pricing, "Continue" button.
- "Restore Purchases" button calls `restorePurchases()`.
- On successful purchase, update UI and sync entitlement to backend.

## Backend Webhook

- RevenueCat sends webhook events to Firebase Function `/revenuecatWebhook`.
- Validate event signature (using RevenueCat secret).
- Update `users/{userId}.subscriptionStatus` based on event type (`INITIAL_PURCHASE`, `RENEWAL`, `CANCELLATION`, `EXPIRATION`).
- Map RevenueCat app user ID to our Firebase user ID (stored in `users.revenueCatId`).

## Cancellation Policy

- Users must cancel via device OS settings (App Store/Play Store).
- App provides a link to system subscription settings (`Linking.openURL('app-settings:')`).
- We do not implement in-app cancellation (per Apple guidelines).