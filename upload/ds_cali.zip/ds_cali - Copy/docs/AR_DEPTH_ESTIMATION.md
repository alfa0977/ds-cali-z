# AR & Depth Estimation

## Objective

Use smartphone depth sensors (LiDAR or ToF) or AI-based monocular depth estimation to measure food volume, improving calorie accuracy.

## Supported Devices

- **LiDAR**: iPhone Pro models (12 Pro+), iPad Pro.
- **ToF**: Some high-end Android devices.
- **No depth sensor**: Fallback to AI-only estimation (2D).

## Implementation

### Native Module: DepthCapture

Create a custom native module (Expo module) that exposes:

```typescript
interface DepthCaptureModule {
  captureWithDepth(): Promise<{
    image: string;       // base64 or local path
    depthMap?: string;   // base64 or local path of raw depth data
    depthWidth: number;
    depthHeight: number;
    unit: 'meters';
  }>;
}
```
#### iOS (ARKit)

-   Use `ARWorldTrackingConfiguration` with `frameSemantics = .smoothedSceneDepth`.
    
-   Capture `ARFrame` and extract `sceneDepth.depthMap` as `CVPixelBuffer`.
    
-   Convert to `Float32Array` and save to temporary file.
    
-   Include camera image as JPEG.
    

#### Android (ARCore)

-   Use `ARCore` with `Depth API` (if supported).
    
-   Otherwise, use `Camera2` + `DepthAware` (few devices).
    
-   Fallback: use monocular depth estimation via TensorFlow Lite model (optional).
    

### Depth Map Format

-   Raw binary of `Float32` values, row-major, width \* height.
    
-   Values in meters, 0 = invalid/no depth.
    
-   Compressed with gzip before upload to save bandwidth.
    

### Calibration

-   User must place a reference object (e.g., standard dinner plate) in frame.
    
-   Or use known plate size stored in user profile.
    
-   Depth values are relative; we compute scale factor by detecting plate diameter in image and depth.
    

### Volume Estimation Algorithm

1.  Segment food regions in image (using AI or color clustering).
    
2.  For each region, sample depth pixels to get average depth.
    
3.  Estimate area in world units using camera intrinsics and depth.
    
4.  Volume = area \* average height (from depth variance).
    
5.  Multiply by food density to get weight.
    

### Fallback

If no depth map, use AI model to estimate portion size relative to reference object (e.g., "plate is 10 inches, food covers 40% of plate area"). Volume estimated as percentage of known plate volume.

### Testing

-   Unit tests for depth conversion functions.
    
-   Integration test with simulated depth map.
