# AI Pipeline

## Overview

The AI pipeline analyzes a meal image (and optionally a depth map) to identify ingredients and estimate their weights and nutritional macros. It uses a multimodal LLM (OpenAI GPT-4o primary, Google Gemini 1.5 Pro fallback) with a strict JSON output schema.

## Components

### 1. Preprocessing (Mobile)

- Image compression (max 1024px, JPEG quality 80) to reduce upload size.
- Quality checks: brightness, blur detection, contrast.
- If depth map available, convert to normalized format (see AR_DEPTH_ESTIMATION.md).

### 2. Upload (Mobile → Firebase Storage)

- Image uploaded to `meal-images/{userId}/{timestamp}.jpg`.
- Depth map uploaded to `depth-maps/{userId}/{timestamp}.bin` (Float32 raw).
- URLs passed to backend.

### 3. AI Vision Call (Backend)

**Prompt Template** (simplified):
```text
You are a nutritionist AI. Analyze the given meal image and estimate the ingredients and their weights in grams. If a depth map is provided, use it to refine volume estimates. Respond with a JSON object following the schema below.

Image URL: {imageUrl}  
Depth Map URL: {depthMapUrl?}  
Reference Object: {referenceObject}

JSON Schema:  
{  
"ingredients": \[  
{  
"name": "string",  
"estimatedWeightGrams": "number",  
"volumeMl": "number?",  
"confidence": "number (0-1)"  
}  
\],  
"healthScore": "number (0-100)"  
}
```
**Response Parsing**:

- Validate against Zod schema.
- If parsing fails, attempt one retry with corrected prompt.
- If still fails, call fallback model (Gemini) with same prompt.

### 4. Volume Correction (Backend)

- If depth map available, use it to compute actual volume of each ingredient region.
- Convert volume to weight using food density database (`densityGramsPerMl` in `foods` collection).
- Override AI's `estimatedWeightGrams` with corrected value, adjust confidence.

### 5. Macro Calculation

- Sum macros from ingredient weights:
  - Use USDA food composition data (or trusted database) stored in `foods`.
  - If exact food not found, use closest match with nutritional info.
- Health score: computed from balance of macros, presence of vegetables, etc. (simple heuristic).

### 6. Storage

- Raw AI response saved to `aiAnalyses/{analysisId}`.
- Corrected result saved to `aiAnalyses` and returned to mobile.
- User can later edit; corrected meal saved to `meals`.

## Error Handling

- Invalid image: return 400 with user-friendly message.
- AI timeout: retry once with backoff.
- Fallback chain: OpenAI → Gemini → generic fallback (use average plate composition).