# Authentication

## Providers

- Apple Sign-In (iOS mandatory)
- Google Sign-In (Android, iOS optional)
- No email/password (to simplify)

## Firebase Auth Setup

- Enable Apple and Google sign-in methods in Firebase Console.
- Configure OAuth credentials:
  - Apple: Service ID, Key ID, Team ID, private key.
  - Google: Web client ID for iOS/Android.

## Mobile Flow

1. User taps "Sign in with Apple" or "Continue with Google".
2. Call native SDK to get identity token.
3. Pass token to Firebase `signInWithCredential`.
4. On success, retrieve `user` object and update Firestore `users/{userId}` with profile info.
5. If new user, create `users` document with default goals.

## Token Refresh

- Firebase SDK handles token refresh automatically.
- For Apple, refresh token may need re-authentication; check `credential` validity and prompt if expired.

## Session Management

- Use `@react-native-async-storage/async-storage` to persist Firebase auth state.
- Listen to `onAuthStateChanged` to update UI.

## Logout & Account Deletion

- Logout: `signOut()`.
- Account deletion: call Cloud Function `/deleteUser` which:
  - Deletes user from Firebase Auth.
  - Deletes all Firestore data (users, meals, logs, healthDaily, aiAnalyses).
  - Deletes all Storage files under user folder.
  - Revokes RevenueCat subscription.