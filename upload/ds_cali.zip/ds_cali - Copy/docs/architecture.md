# Architecture

## High-Level Overview

The system consists of three main parts:

1. **Mobile App** (React Native + Expo) – all user-facing features, camera/AR, health sync, UI.
2. **Backend** (Firebase Cloud Functions) – API endpoints, AI orchestration, data processing, storage.
3. **External Services** – OpenAI/Gemini, RevenueCat, Apple HealthKit, Google Fit, barcode lookup.

```mermaid
flowchart LR
    M[Mobile App] -->|Firebase Auth| FA[Firebase Auth]
    M -->|Upload image/depth| ST[Firebase Cloud Storage]
    M -->|HTTPS| FB[Firebase Cloud Functions]
    M -->|RevenueCat SDK| RC[RevenueCat]
    
    FB --> AI[AI Vision Service]
    FB --> FS[(Firestore)]
    FB --> ST
    FB --> BR[Barcode Lookup]
    
    M -->|Native modules| HK[HealthKit/Google Fit]
    HK -->|Sync aggregate data| FB

```
## Component Details

### Mobile App (apps/mobile)

## 

-   Expo prebuild (managed workflow with custom native code)
    
-   Navigation: React Navigation (Stack + Tabs)
    
-   State Management: Zustand + React Query
    
-   UI: Custom design system (`packages/ui`)
    
-   Native Modules:
    
    -   `HealthSync` – wraps HealthKit/Google Fit
        
    -   `DepthCapture` – wraps ARKit/ARCore depth API
        
-   Camera: `expo-camera` + custom AR session
    

### Backend (apps/functions)

## 

-   Runtime: Node.js 20 on Firebase Cloud Functions v2
    
-   API Endpoints (all under `/api`):
    
    -   `/analyzeMeal` – POST: image + depth map → AI analysis
        
    -   `/logMeal` – POST: save a meal log
        
    -   `/searchFoods` – GET: search food database
        
    -   `/logFood` – POST: log a specific food item
        
    -   `/syncHealth` – POST: receive aggregated health data
        
    -   `/getUserDashboard` – GET: return dashboard data for a date range
        
-   Triggers:
    
    -   Firestore `onCreate` for `aiAnalyses` → trigger post-processing
        
    -   Scheduled function to clean up orphaned storage files
        
-   Services:
    
    -   `ai-engine` package for prompt formatting, schema validation, fallback
        
    -   `depth-processing` for depth map normalization
        
-   Database: Firestore (NoSQL)
    
-   Storage: Cloud Storage for images and depth maps
    

### Shared Packages

## 

-   contracts: TypeScript types and Zod schemas shared across frontend/backend.
    
-   ai-engine: Prompt templates, response parsing, volume estimation logic.
    
-   depth-processing: Utilities for depth map conversion, calibration.
    
-   health-sync: Native module interface definitions and platform adapters.
    
-   ui: Reusable React Native components, theme tokens.
    

## Data Flow: Meal Scanning

## 

1.  User opens scanner → app checks camera permissions, lighting.
    
2.  AR session starts, captures RGB frame + optional depth map.
    
3.  User captures image; app runs quality preflight (lighting, focus, blur).
    
4.  If pass, image and depth map are uploaded to Cloud Storage.
    
5.  Backend receives URLs and reference object, calls AI vision service.
    
6.  AI returns ingredients with estimated weights/volumes.
    
7.  Backend applies depth correction (if depth map available) using food density DB.
    
8.  Backend calculates macros and health score, returns result.
    
9.  Mobile displays result card; user can edit ingredients/portions ("Fix Results").
    
10.  User confirms; meal log is saved to Firestore.
