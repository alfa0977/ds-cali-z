# Security & Privacy

## Data Protection

- All Firestore and Storage access restricted via security rules.
- Firestore rules:
  - `users`: only owner can read/write.
  - `foods`: public read (database), user-created foods only owner write.
  - `meals`, `logs`, `healthDaily`, `aiAnalyses`: only owner can read/write.
- Storage rules:
  - Only authenticated user can upload to their folder.
  - Only owner can read their files.

## Image and Depth Data

- Meal images are private; never public.
- Depth maps are considered biometric data (indirectly). Store securely, delete after analysis if not needed for audit.
- Users can request deletion of all images and analysis history.

## Health Data

- HealthKit/Google Fit data is aggregated before storage; no raw health samples.
- Explicit consent during onboarding.
- Option to disconnect and delete health data.

## AI Data Usage

- AI calls do not include any user identifiers; image is processed but not stored by third-party AI providers (OpenAI/Gemini) beyond their standard retention (set to zero data retention if possible).
- We do not use meal images for training without consent.

## API Security

- All backend endpoints require Firebase ID token verification.
- Rate limiting to prevent abuse.
- Input validation with Zod.

## Secrets Management

- API keys (OpenAI, Google, RevenueCat) stored only in Firebase Functions environment variables (or Secret Manager).
- Never in mobile app.

## Compliance

- GDPR: Data deletion request endpoint.
- CCPA: Do not sell data.
- COPPA: App not intended for children under 13.