# Health Sync

## Overview

The app reads health data (steps, active energy, workouts, weight) from Apple HealthKit and Google Fit. Data is aggregated daily and stored in Firestore for dashboard display and historical trends.

## iOS – HealthKit

- **Permissions**: Request read access for:
  - `HKQuantityTypeIdentifier.stepCount`
  - `HKQuantityTypeIdentifier.activeEnergyBurned`
  - `HKQuantityTypeIdentifier.bodyMass`
  - `HKWorkoutTypeIdentifier`
- **Native Module**: `HealthSync` (Swift)
  - Method `getDailyMetrics(date: Date): Promise<HealthMetrics>`
  - Method `getWorkouts(date: Date): Promise<WorkoutSummary[]>`
  - Background delivery: use `HKObserverQuery` and background fetch to update when app is not active (optional).
- **Data Mapping**:
  - Steps → `healthDaily.steps`
  - Active Energy (kcal) → `healthDaily.activeEnergyKcal`
  - Weight (kg) → `healthDaily.weightKg`
  - Workouts → array of `{ type, durationMinutes, intensity, caloriesBurned }`

## Android – Google Fit

- **Permissions**: OAuth 2.0 scopes:
  - `https://www.googleapis.com/auth/fitness.activity.read`
  - `https://www.googleapis.com/auth/fitness.body.read`
- **Native Module**: `HealthSync` (Kotlin)
  - Use `Fitness.getHistoryClient` to read data.
  - Authenticate using `GoogleSignIn` account.
  - Method `getDailyMetrics(date: Date): Promise<HealthMetrics>`
- **Data Mapping**: Same as iOS.

## Sync Strategy

- On app foreground, check last sync timestamp.
- If older than 1 hour, pull current day's data and send to backend `/syncHealth`.
- Backend upserts `healthDaily` document for that user/date.
- For historical days (e.g., when user opens progress dashboard), fetch missing days on demand.
- Store only aggregated metrics, not raw health samples.

## Water Write-Back

- Optional: user can choose to write water intake to HealthKit (`HKQuantityTypeIdentifier.dietaryWater`).
- Google Fit does not have water type; skip on Android.

## Privacy

- Health data is considered sensitive; only store aggregated daily values in Firestore.
- Allow user to disconnect health sync from settings, which deletes all `healthDaily` documents.
- Do not share health data with third parties.