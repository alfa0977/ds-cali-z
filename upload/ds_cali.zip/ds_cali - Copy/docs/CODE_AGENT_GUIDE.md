# Code Agent Guide

This guide is for AI coding agents to understand repository conventions and build order.

## Conventions

- **Language**: TypeScript everywhere.
- **Package Manager**: pnpm.
- **Monorepo**: Turborepo pipelines defined in `turbo.json`.
- **Linting/Formatting**: ESLint + Prettier via `packages/config`.
- **Environment Variables**: Use `.env` files, never hardcode secrets.
- **API Contracts**: All request/response types defined in `packages/contracts` and validated with Zod.

## Build Order

1. Start with `packages/contracts` – define all shared types and schemas.
2. Then `packages/ui` – design system components.
3. Then `apps/functions` – backend APIs and services.
4. Then `apps/mobile` – screens and features, using contracts and UI.

## Task Assignment

Each feature should be implemented as a self-contained module in `apps/mobile/src/features/<feature-name>`.
Corresponding backend logic in `apps/functions/src/api` or `src/services`.
Shared logic in `packages/*`.

## Example: Implementing Meal Logging

1. Define `LogMealRequest` and `LogMealResponse` in `packages/contracts`.
2. Create Firestore write logic in `apps/functions/src/api/logMeal.ts`.
3. Create mobile service `src/services/mealService.ts` that calls the API.
4. Build UI components in `src/features/manual-logging/` and `src/features/result-card/`.

## Testing

- Unit tests for pure logic (AI parsing, depth conversion, macro calculation).
- Integration tests for Firebase Functions using emulator.
- E2E tests not required initially.

## Documentation

- Update relevant MD file when changing architecture or data model.
- Keep code comments for complex logic.

## Git Workflow

- Feature branches from `main`.
- PRs with description and test checklist.
- No direct commits to main.