
# Roadmap

## Phase 0 – Foundation (Weeks 1–2)

- [ ] Monorepo setup: pnpm workspaces, Turborepo, shared configs
- [ ] Expo app scaffold with TypeScript, navigation, theme
- [ ] Firebase project configured (Auth, Firestore, Storage, Functions)
- [ ] Shared TypeScript contracts package with core types
- [ ] CI pipeline for mobile and functions
- [ ] Design system tokens in `packages/ui`

**Acceptance**: Repo builds and runs; auth placeholder screen; CI green.

---

## Phase 1 – User Profile & Onboarding (Weeks 3–4)

- [ ] Apple/Google sign-in via Firebase Auth
- [ ] User profile creation (goals, weight, height)
- [ ] HealthKit/Google Fit permissions request flow
- [ ] Settings screen with logout, data deletion
- [ ] RevenueCat SDK integration and paywall skeleton

**Acceptance**: User can sign in, set goals, grant health permissions.

---

## Phase 2 – Manual & Barcode Logging (Weeks 5–6)

- [ ] Food database seeded with common foods
- [ ] Search API endpoint
- [ ] Barcode scanner using `expo-barcode-scanner`
- [ ] Manual food entry form (description, macros, serving)
- [ ] Log meal to Firestore
- [ ] Recent feed on Home dashboard

**Acceptance**: User can log a meal via search, barcode, or manual entry; feed updates.

---

## Phase 3 – AI Visual Logger (Weeks 7–10)

- [ ] Camera scanner UI with framing guide
- [ ] Lighting/quality prompt
- [ ] ARKit/ARCore depth capture (native module)
- [ ] Image and depth upload to Cloud Storage
- [ ] Backend `/analyzeMeal` endpoint
- [ ] AI engine prompt and schema
- [ ] Volume estimation with fallback
- [ ] Result card UI with macros, health score, ingredients
- [ ] "Fix Results" editing flow

**Acceptance**: User can scan a meal, see AI results, edit if needed, and save.

---

## Phase 4 – Home & Progress Dashboards (Weeks 11–13)

- [ ] Weekly habit tracker rings
- [ ] Steps card (circular progress)
- [ ] Calories burned card
- [ ] Water logging card (+/-)
- [ ] Recently logged feed with macro breakdown
- [ ] Progress dashboard: weight graph (SVG/Chart), days logged widget
- [ ] Time filters (90d, 6m, 1y, all)
- [ ] Motivation banner

**Acceptance**: Dashboards display correct data from Firestore and health sync.

---

## Phase 5 – Monetization, Sync, Polish (Weeks 14–16)

- [ ] RevenueCat full integration: paywall, restore purchases, webhook
- [ ] Apple/Google subscription status sync to Firestore
- [ ] HealthKit/Google Fit background sync (daily aggregate)
- [ ] Water logging write-back to HealthKit (optional)
- [ ] Analytics (Firebase Analytics + Crashlytics)
- [ ] Performance optimization, image compression
- [ ] Security review and Firestore rules
- [ ] TestFlight / Play Store beta release

**Acceptance**: App is production-ready, subscriptions work, health sync reliable.