# Data Model

Firestore is used as the primary database. Documents are stored in collections. All IDs are auto-generated or composite keys.

## Collections

### users
Document ID: `{userId}` (from Firebase Auth)

| Field | Type | Description |
|-------|------|-------------|
| email | string | User's email |
| displayName | string | Full name |
| avatarUrl | string? | Profile photo URL |
| goals | object | `{ calories: number, protein: number, carbs: number, fat: number }` |
| subscriptionStatus | string | `active`, `trialing`, `expired`, `none` |
| revenueCatId | string? | RevenueCat app user ID |
| createdAt | timestamp | Creation time |
| lastLoginAt | timestamp | Last sign-in |

### foods
Document ID: `{foodId}` (auto or from seed)

| Field | Type | Description |
|-------|------|-------------|
| name | string | e.g., "Avocado" |
| servingSize | string | e.g., "1 medium" |
| servingWeightGrams | number | Weight of one serving |
| calories | number | kcal per serving |
| protein | number | grams per serving |
| carbs | number | grams per serving |
| fat | number | grams per serving |
| source | string | `database`, `user`, `ai` |
| barcode | string? | UPC/EAN if applicable |
| densityGramsPerMl | number? | Food density for volume conversion |
| createdBy | string? | userId if user-created |

### meals
Document ID: `{mealId}`

| Field | Type | Description |
|-------|------|-------------|
| userId | string | Owner |
| source | string | `ai`, `manual`, `barcode` |
| ingredients | array | List of `IngredientResult` objects (see below) |
| macros | object | `{ calories, protein, carbs, fat }` |
| healthScore | number | 0–100 |
| imageUrl | string? | Cloud Storage URL of meal photo |
| depthMapUrl | string? | Cloud Storage URL of depth map |
| createdAt | timestamp | Capture time |

**IngredientResult** (embedded in meals):
```typescript
{
  name: string;
  estimatedWeightGrams: number;
  volumeMl?: number;
  confidence: number; // 0–1
}

### logs

Document ID: `{logId}`

| Field | Type | Description |
| --- | --- | --- |
| userId | string | Owner |
| type | string | `meal`, `water`, `workout` |
| mealId | string? | Reference to meals doc if type=meal |
| timestamp | timestamp | When logged |
| macros | object? | `{ calories, protein, carbs, fat }` (for meals) |
| waterMl | number? | For water logs |
| workoutSummary | object? | For workout logs: `{ type, durationMinutes, intensity, caloriesBurned }` |
| imageUrl | string? | Thumbnail |
| corrected | boolean | Whether user edited AI result |

### healthDaily

Document ID: `{userId}_{YYYY-MM-DD}` (composite)

| Field | Type | Description |
| --- | --- | --- |
| userId | string |  |
| date | string | YYYY-MM-DD |
| steps | number |  |
| activeEnergyKcal | number |  |
| waterMl | number |  |
| weightKg | number? |  |
| workouts | array | Workout summaries |
| updatedAt | timestamp | Last sync time |

### aiAnalyses

Document ID: `{analysisId}`

| Field | Type | Description |
| --- | --- | --- |
| userId | string |  |
| rawResponse | object | Raw AI output |
| correctedResponse | object | After depth correction |
| imageUrl | string |  |
| depthMapUrl | string? |  |
| createdAt | timestamp |  |

## Indexes

-   `logs`: composite index on `(userId, timestamp desc)` for recent feed.
    
-   `healthDaily`: composite index on `(userId, date)`.
    
-   `foods`: composite index on `(name)` for text search (or use Algolia for full-text).