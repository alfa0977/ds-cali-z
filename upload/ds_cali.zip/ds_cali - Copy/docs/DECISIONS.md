# Architecture Decision Records

## ADR-001: Mobile Framework – React Native + Expo

**Status**: Accepted  
**Date**: 2024-01-15  
**Context**: Need cross-platform app with camera, ARKit/ARCore, health integrations.  
**Decision**: Use React Native with Expo prebuild (managed workflow with custom native code).  
**Consequences**: Faster development, large ecosystem, but need custom native modules for depth.  

## ADR-002: Backend – Firebase Cloud Functions

**Status**: Accepted  
**Date**: 2024-01-15  
**Context**: Need scalable serverless backend with minimal DevOps.  
**Decision**: Firebase Cloud Functions v2 with Firestore and Storage.  
**Consequences**: Vendor lock-in, but rapid development and built-in triggers.  

## ADR-003: AI Provider – OpenAI GPT-4o primary, Gemini fallback

**Status**: Accepted  
**Date**: 2024-01-20  
**Context**: Need high accuracy food recognition; provider redundancy.  
**Decision**: Use OpenAI as primary due to better vision performance, Gemini as fallback to avoid downtime.  
**Consequences**: Cost higher, but reliability improved.  

## ADR-004: Depth Estimation – Hybrid approach

**Status**: Accepted  
**Date**: 2024-02-01  
**Context**: Most phones don't have depth sensors.  
**Decision**: Use LiDAR/ToF when available; fallback to AI portion estimation.  
**Consequences**: Improved accuracy on supported devices, still works on all phones.  

## ADR-005: Monorepo – pnpm + Turborepo

**Status**: Accepted  
**Date**: 2024-01-10  
**Context**: Need shared code between mobile and backend.  
**Decision**: Use pnpm workspaces with Turborepo for task orchestration.  
**Consequences**: Efficient caching, but requires discipline in dependency management.