cal-ai/
├── apps/
│   ├── mobile/                         # React Native + Expo app
│   │   ├── src/
│   │   │   ├── features/
│   │   │   │   ├── auth/
│   │   │   │   ├── scanner/
│   │   │   │   ├── result-card/
│   │   │   │   ├── manual-logging/
│   │   │   │   ├── dashboard/
│   │   │   │   ├── progress/
│   │   │   │   ├── food-database/
│   │   │   │   ├── paywall/
│   │   │   │   └── settings/
│   │   │   ├── navigation/
│   │   │   ├── services/
│   │   │   ├── components/
│   │   │   ├── theme/
│   │   │   └── utils/
│   │   └── README.md
│   └── functions/                      # Firebase Cloud Functions
│       ├── src/
│       │   ├── api/
│       │   ├── triggers/
│       │   ├── services/
│       │   └── models/
│       └── README.md
├── packages/
│   ├── ai-engine/                      # AI prompt, schema, parsing, volume logic
│   ├── health-sync/                    # HealthKit/Google Fit native modules
│   ├── contracts/                      # Shared TypeScript types + Zod schemas
│   ├── ui/                             # Design system / shared UI components
│   ├── config/                         # ESLint, TSConfig, Prettier
│   └── depth-processing/               # Depth map normalization, point cloud helpers
├── docs/
│   ├── ARCHITECTURE.md
│   ├── ROADMAP.md
│   ├── PROJECT_BREAKDOWN.md
│   ├── DATA_MODEL.md
│   ├── AI_PIPELINE.md
│   ├── AR_DEPTH_ESTIMATION.md
│   ├── HEALTH_SYNC.md
│   ├── AUTH.md
│   ├── PAYMENTS.md
│   ├── SECURITY_AND_PRIVACY.md
│   ├── CODE_AGENT_GUIDE.md
│   └── DECISIONS.md
├── .github/
│   └── workflows/
│       ├── mobile-ci.yml
│       └── functions-ci.yml
├── package.json
├── turbo.json
└── pnpm-workspace.yaml