# Cal AI Clone

A calorie tracking app that uses AI vision and depth sensing to log meals, syncs with health platforms, and provides a comprehensive dashboard.

## Tech Stack

- **Mobile**: React Native + Expo (TypeScript)
- **Backend**: Node.js + Firebase (Cloud Functions, Firestore, Storage, Auth)
- **AI**: OpenAI GPT-4o (primary) + Google Gemini 1.5 Pro (fallback)
- **AR/Depth**: React Native ARKit/ARCore via custom native modules
- **Payments**: RevenueCat
- **Monorepo**: pnpm + Turborepo

## Repository Structure
```code
cal-ai/
├── apps/
│ ├── mobile/ # React Native Expo app
│ └── functions/ # Firebase Cloud Functions
├── packages/
│ ├── ai-engine/ # AI prompt, JSON schema, parsing
│ ├── health-sync/ # HealthKit/Google Fit native modules
│ ├── contracts/ # Shared TypeScript types & Zod schemas
│ ├── ui/ # Design system & shared components
│ ├── config/ # ESLint, TSConfig, Prettier
│ └── depth-processing/ # Depth map utilities
├── docs/ # Documentation (see below)
└── ... # Tooling configs
```

## Getting Started

### Prerequisites

- Node.js ≥ 18
- pnpm ≥ 8
- Firebase CLI (`npm i -g firebase-tools`)
- Expo CLI (`npm i -g expo-cli`)
- Xcode / Android Studio for native builds

### Environment Setup

1. Clone repo and install dependencies:
   ```bash
   pnpm install
    ```
## 2\. Router Logic (How to pick the right question)

Do not pick randomly. Use this weighted selection algorithm:

1.  Weakness Targeting: Check the user's PostgreSQL record. If they have a low average score (e.g., < 6) on "Environment", give `weight: 3` to all env topics.
    
2.  Task Continuity (The "Thread" Rule):
    
    -   If you ask `Task 2` about "Technology", the immediate `Task 3` follow-ups _must_ come from that same card.
        
    -   If the user finishes Task 3 and asks for a new question, pick a completely different topic to maximize vocabulary exposure.
        
3.  Difficulty Scaling:
    
    -   If the user scores > 7.5 on two consecutive tasks, automatically switch the `difficulty` filter to "Hard" only.
        

## 3\. Cue Card Rendering (For TTS)

When the agent speaks a Task 2 Cue Card, it must break it down clearly:

> _"Describe a natural place you have visited. (Pause) You should say: (Pause) where it was, (Pause) when you went there, (Pause) what you did there, (Pause) and explain why you liked it."_

The backend should split the `cue_card` text by `"."` and `","` and inject short 0.3s pauses to give the user time to mentally note the points.

## 4\. Extending the Bank

-   Weekly Update: The product owner must add 5 new topics per week.
    
-   Crowdsourcing: If the user gives a fantastic response that the LLM marks as Band 9, save the user's transcript and the question as a new "Few-shot Example" to inject into the prompt for future users attempting that card.

```bash
pnpm dev          # starts both mobile and functions (using Firebase emulator)
```
## Documentation Index

-   [Architecture](https://docs/ARCHITECTURE.md)
    
-   [Roadmap](https://docs/ROADMAP.md)
    
-   [Project Breakdown](https://docs/PROJECT_BREAKDOWN.md)
    
-   [Data Model](https://docs/DATA_MODEL.md)
    
-   [AI Pipeline](https://docs/AI_PIPELINE.md)
    
-   [AR & Depth Estimation](https://docs/AR_DEPTH_ESTIMATION.md)
    
-   [Health Sync](https://docs/HEALTH_SYNC.md)
    
-   [Authentication](https://docs/AUTH.md)
    
-   [Payments](https://docs/PAYMENTS.md)
    
-   [Security & Privacy](https://docs/SECURITY_AND_PRIVACY.md)
    
-   [Code Agent Guide](https://docs/CODE_AGENT_GUIDE.md)
    
-   [Decisions](https://docs/DECISIONS.md)
