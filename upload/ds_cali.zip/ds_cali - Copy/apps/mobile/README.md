# Mobile App

## Setup

1. Install dependencies: `pnpm install` (from root)
2. Create `.env` file with:
```text

EXPO\_PUBLIC\_FIREBASE\_API\_KEY=  
EXPO\_PUBLIC\_FIREBASE\_AUTH\_DOMAIN=  
EXPO\_PUBLIC\_FIREBASE\_PROJECT\_ID=  
EXPO\_PUBLIC\_FIREBASE\_STORAGE\_BUCKET=  
EXPO\_PUBLIC\_FIREBASE\_MESSAGING\_SENDER\_ID=  
EXPO\_PUBLIC\_FIREBASE\_APP\_ID=  
EXPO\_PUBLIC\_REVENUECAT\_API\_KEY\_IOS=  
EXPO\_PUBLIC\_REVENUECAT\_API\_KEY\_ANDROID=
```
3. Run: `pnpm --filter mobile start` (Expo dev server)

## Build

- iOS: `pnpm --filter mobile ios`
- Android: `pnpm --filter mobile android`

## Features Structure
```text
src/
features/
auth/
scanner/
result-card/
manual-logging/
dashboard/
progress/
food-database/
paywall/
settings/
navigation/
services/
components/
theme/
utils/
```

## Native Modules

- `HealthSync`: located in `modules/health-sync/`
- `DepthCapture`: located in `modules/depth-capture/`