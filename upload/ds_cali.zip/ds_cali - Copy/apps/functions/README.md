# Firebase Cloud Functions

## Setup

1. Install Firebase CLI: `npm i -g firebase-tools`
2. Login: `firebase login`
3. Initialize: `firebase init functions` (inside `apps/functions`)
4. Set environment variables:
```text
OPENAI_API_KEY=
GEMINI_API_KEY=
REVENUECAT_WEBHOOK_SECRET=
```
5. Deploy: `firebase deploy --only functions`

## Local Development

- Run emulator: `firebase emulators:start`
- Use `npm run serve` to watch TypeScript.

## API Endpoints

All routes require `Authorization: Bearer <Firebase ID token>`.

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/analyzeMeal` | Analyze meal image |
| POST | `/api/logMeal` | Save meal log |
| GET | `/api/searchFoods?q=` | Search foods |
| POST | `/api/logFood` | Log a single food |
| POST | `/api/syncHealth` | Sync health data |
| GET | `/api/getUserDashboard?start=&end=` | Dashboard data |

## Folder Structure
```text
src/
api/ # HTTP handlers
triggers/ # Firestore triggers, scheduled functions
services/ # AI, barcode, density
models/ # Data access
```
